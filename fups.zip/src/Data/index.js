import Data_Dashboard from "./json/dashboard.json"
import Data_Login from "./json/login.json"
import Data_Users from "./json/users.json"
import Data_Types from "./json/types.json"
import Data_Loading from "./json/loading.json"

export { Data_Dashboard, Data_Login, Data_Users, Data_Types, Data_Loading }