import React from "react"

import FupsLogin from "../../Components/FupsLogin/FupsLogin.js"

function Login({ setLogin }) {
    return (<FupsLogin setLogin={setLogin} />)
}

export default Login